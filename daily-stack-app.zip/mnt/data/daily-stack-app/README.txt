Daily Stack prototype

Files:
- index.html: local-first web app

How to use on iPhone:
1. Open index.html in Safari (or host it anywhere simple).
2. Use Share > Add to Home Screen.
3. Open from the Home Screen for the best app-like experience.
4. Data is stored only in the browser on that device.

Notes:
- This prototype is strongest as a checklist/tracker.
- Browser notifications on iPhone can be finicky compared with Apple Reminders.
- For production, a native SwiftUI app would be better.
