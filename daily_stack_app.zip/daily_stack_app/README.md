# Daily Stack App

A lightweight iPhone-friendly web app for tracking Chris's daily medication and supplement routine.

## Included
- Apple-style UI
- Daily checklist with persistence
- Streak tracking
- Energy score logging
- PWA manifest for Add to Home Screen
- Service worker for basic offline support

## Files
- `index.html` - full app
- `manifest.webmanifest` - installable web app metadata
- `sw.js` - offline caching

## GitHub Pages deployment
1. Create a GitHub repo.
2. Upload all files in this folder.
3. Go to **Settings > Pages**.
4. Set source to **Deploy from a branch**.
5. Pick `main` branch and `/root`.
6. Save.
7. Open the GitHub Pages URL in Safari on iPhone.
8. Use **Share > Add to Home Screen**.

## Reminder note
Web-app notifications on iPhone can work, but they are not as reliable as Apple Reminders for medication-critical alerts. Keep Apple Reminders as a backup if you need guaranteed prompts.
